<!-- db: jedzenie
  - table produkt:
    - id
    - nazwa
    - idrodzaj
    - data
  - rodzaj
    - idrodzaj
    - rodzaj

na str
2*a produkt, usuń

produkt -> tabela produktów i aktualizuj po nacsnieciu formularz z auktualizacja rekordu
usun -> formularz wpisac rodzaj. po nacisnieciu usuwa wszystkie produkty danego rodzaju -->
<!DOCTYPE html>
<html lang="pl" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Sprawdzian</title>
  </head>
  <body>
    <?php
    $con = new mysqli('localhost', 'root', '', 'jedzenie');
    if (empty($_GET['table'])) {
      echo "<a href='Szczyt.php?table=1'>Produkt</a><br>";
    }else {
      echo <<<TABLE
      <table>
        <tr>
          <th>Nazwa</th>
          <th>Rodzaj</th>
          <th>Data dodania</th>
        </tr>
      TABLE;
      $sql = "SELECT id, nazwa, rodzaj, data FROM produkt p INNER JOIN rodzaj r ON p.id_rodzaj = r.id_rodzaj";
      $res = $con->query($sql);
      while($row = $res->fetch_assoc()) {
        echo <<<ROW
          <tr>
            <td>$row[nazwa]</td>
            <td>$row[rodzaj]</td>
            <td>$row[data]</td>
            <td><a href='Szczyt.php?update=$row[id]'>Aktualizuj</a></td>
          <tr>
        ROW;
      }
      echo "</table>";
    }

    if (!empty($_GET['update'])) {
      $row = $con->query("SELECT * FROM produkt WHERE id='$_GET[update]'")->fetch_assoc();
      echo <<<FORM
      <form action="scripts/update.php" method="get">
        <input type="number" name="id" value="$row[id]" readonly> <br>
        <input type="text" name="nazwa" value="$row[nazwa]"> <br>
        <select name="id_rodzaj">
      FORM;
      $res = $con->query("SELECT * FROM rodzaj");
      while ($row = $res->fetch_assoc()) {
        echo "<option value='$row[id_rodzaj]'";
        if ($row['id_rodzaj'] == $_GET['update']) {
          echo " default ";
        }
        echo ">$row[rodzaj]</option>";
      }
      echo <<<FORM
        </select>
        <input type="submit" value="Aktualizuj">
      </form>
      FORM;
    }

    if (empty($_GET['delete'])) {
      echo "<a href='Szczyt.php?delete=1'>Usuń</a>";
    }else {
      echo <<<FORM
      <form action="scripts/delete.php" method="get">
        <input type="text" placeholder="Podaj rodzaj" name="rodzaj"> <br>
        <input type="submit" value="Usuń">
      </form>
      FORM;
    }

    if (!empty($_GET['msg'])) {
      echo "<h3>$_GET[msg]</h3>";
    }
    $con->close();
    ?>
  </body>
</html>
