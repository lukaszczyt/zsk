<?php
if (!empty($_GET['rodzaj'])) {
  $con = new mysqli('localhost', 'root', '', 'jedzenie');
  $sql = "DELETE FROM produkt WHERE id_rodzaj = (SELECT id_rodzaj FROM rodzaj WHERE rodzaj = '$_GET[rodzaj]')";
  $con->query($sql);
  $ar = $con->affected_rows;
  $con->close();
  header("location: ../Szczyt.php?msg=Usunięto $ar wierszy");
}
?>
