<?php
$con = new mysqli('localhost', 'root', '', 'jedzenie');
$sql = "UPDATE produkt SET nazwa='$_GET[nazwa]', id_rodzaj='$_GET[id_rodzaj]' WHERE id='$_GET[id]'";
$con->query($sql);
$af = $con->affected_rows;
$con->close();
header("location: ../Szczyt.php?msg=Zauktualizowano $af wierszy");
?>
