<?php
foreach ($_POST as $key => $value) {
  if($value==""){
    header("location: Szczyt.php?msg=Uzupełnij dane&add=1");
    exit();
  }
}
$con = new mysqli('localhost','root','','animal');
$sql = "INSERT INTO dog(`imie`, `id_rasa`, `data`) VALUES('$_POST[imie]', $_POST[id_rasa], '$_POST[data]')";
$res = $con->query($sql);
// echo $sql;
if($con->affected_rows==1){
  $con->close();
  header("location: Szczyt.php?msg=Dodano pieska");
}else {
  $con->close();
  header("location: Szczyt.php?msg=Nie dodano pieska&add=1");
}
?>
