-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 30 Lis 2021, 11:28
-- Wersja serwera: 10.4.8-MariaDB
-- Wersja PHP: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `animal`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `dog`
--

CREATE TABLE `dog` (
  `id_dog` int(10) UNSIGNED NOT NULL,
  `imie` varchar(32) NOT NULL,
  `id_rasa` int(10) UNSIGNED NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `dog`
--

INSERT INTO `dog` (`id_dog`, `imie`, `id_rasa`, `data`) VALUES
(1, 'Reksio', 1, '2020-11-04'),
(2, 'Cliford', 2, '2020-02-24'),
(3, 'Kulka', 4, '2019-01-22'),
(4, 'Spike', 3, '2018-02-09');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rasa`
--

CREATE TABLE `rasa` (
  `id_rasa` int(10) UNSIGNED NOT NULL,
  `rasa` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Zrzut danych tabeli `rasa`
--

INSERT INTO `rasa` (`id_rasa`, `rasa`) VALUES
(1, 'Kundel'),
(2, 'Mastiff'),
(3, 'Bulldog'),
(4, 'Pitbull');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `dog`
--
ALTER TABLE `dog`
  ADD PRIMARY KEY (`id_dog`),
  ADD KEY `fk_rasa_psa` (`id_rasa`);

--
-- Indeksy dla tabeli `rasa`
--
ALTER TABLE `rasa`
  ADD PRIMARY KEY (`id_rasa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT dla tabeli `dog`
--
ALTER TABLE `dog`
  MODIFY `id_dog` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `rasa`
--
ALTER TABLE `rasa`
  MODIFY `id_rasa` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `dog`
--
ALTER TABLE `dog`
  ADD CONSTRAINT `fk_rasa_psa` FOREIGN KEY (`id_rasa`) REFERENCES `rasa` (`id_rasa`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
