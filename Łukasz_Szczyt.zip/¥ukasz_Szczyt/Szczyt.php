<!--
baza danych: animal
  tabela: dog
    id
    imie
    id_rasa ->
    data
  tabela: rasa
    id_rasa
    rasa
 -->
<!DOCTYPE html>
<html lang="pl" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Łukasz Szczyt</title>
    <style media="screen">
      table, td, th {
        border: 1px solid black;
        border-collapse: collapse;
      }
      h5 {
        color: red;
      }
    </style>
  </head>
  <body>
    <h4>Psy</h4>
    <table>
      <tr>
        <th>imie</th>
        <th>rasa</th>
        <th>data</th>
      </tr>
      <?php
        $con = new mysqli('localhost','root','','animal');
        $sql = "SELECT id_dog, imie, rasa, data FROM dog d INNER JOIN rasa r on d.id_rasa = r.id_rasa ORDER BY 1";
        $res = $con->query($sql);
        while($row = $res->fetch_assoc()){
          echo <<<PIES
            <tr>
              <td>$row[imie]</td>
              <td>$row[rasa]</td>
              <td>$row[data]</td>
            </tr>
          PIES;
        }
      ?>
    </table>
    <a href="Szczyt.php?add=1">Dodaj psa</a>
    <?php
      if(isset($_GET['add'])) {
        echo <<<FORM
        <form action="insert.php" method="post">
          <input type="text" name="imie" placeholder="Podaj imie"> <br>
          <select name="id_rasa">
        FORM;
        $sql = "SELECT * FROM rasa";
        $res = $con->query($sql);
        while($row = $res->fetch_assoc()){
          echo "<option value='$row[id_rasa]'>$row[rasa]</option>";
        }
        echo <<<FORM
          </select> <br>
          <input type="date" name="data"><br>
          <input type="submit" value="Dodaj pieska">
        </form>
        FORM;
      }
      if(!empty($_GET['msg'])){
        echo "<h5>$_GET[msg]</h5>";
      }
      $con->close();
    ?>
  </body>
</html>
