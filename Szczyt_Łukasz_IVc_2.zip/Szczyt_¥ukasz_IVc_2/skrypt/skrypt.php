<!DOCTYPE html>
<html lang="pl" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Wynik</title>
  </head>
  <body>
    <?php
    if(empty($_POST['a']) || empty($_POST['h']) || empty($_POST['ileNazwisk']) || $_POST['a']<=0 || $_POST['h']<=0) {
      ?>
      <script>
        history.back()
      </script>
      <?php
    }else {
      $a = trim($_POST['a']);
      $h = trim($_POST['h']);
      $p = str_replace('.', ',', $a*$h/2);
      echo <<<WYNIK
      Pole to: $p <hr>
      WYNIK;
    }
    $c = trim($_POST['ileNazwisk']);
    for ($i=0; $i < $c; $i++) {
      echo "Łukasz Szczyt<br>";
    }
    ?>
  </body>
</html>
