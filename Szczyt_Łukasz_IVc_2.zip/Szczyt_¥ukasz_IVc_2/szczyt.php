<!DOCTYPE html>

<!--
dodaj formularz z dwoma polami do wpisania danych do trójkąta (a i h). Użytkowmik po zatwierdzeniu formularza jest perzekierowany do skrypt.php. W skrypcie sprawdź, czy użytkownik wypełnił oba pola. Jeśli nie, to cofnij go do strony głównej i wyświetl komunikat, "wypełnij pola". Jeśli wypełnił, to usuń białe znaki i oblicz pole. Wynik wyświetl za pomocą heredoca. Dodaj hiperłącze umożliwiające powrót na stronę główną. Jeśli użytkownik poda liczbę mniejszą lub równą zero, to cofnij go do strony głównej i wyświetl komunikat "liczba musi być większa od zera".
Użytkownik podaje cyfrę. W skrypcie wyświetl swoje imie i nazwisko tyle razy, ile podał w formularzu

### Tego nie
W pierwszym formularzu dodaj pole tekstowe, w którym użytkownik dodaje swoje nazwisko. Po zatwierdzeniu formularza wyświetl te dane przefiltrowane (1. litera duża, reszta małe, brak spacji).
-->

<html lang="pl" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Główna</title>
  </head>
  <body>
    <form action="skrypt/skrypt.php" method="post">
      <input type="number" name="a"><br>
      <input type="number" name="h"><br>
      <input type="number" name="ileNazwisk"><br>
      <input type="submit" value="Zatwierdź">
    </form>
  </body>
</html>
